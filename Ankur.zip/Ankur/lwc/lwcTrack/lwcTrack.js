import { LightningElement } from 'lwc';

export default class LwcTrack extends LightningElement {}