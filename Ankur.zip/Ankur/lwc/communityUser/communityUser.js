/* eslint-disable no-console */
import { LightningElement, api , wire, track} from 'lwc';
import Id from '@salesforce/user/Id';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import updateTasks from '@salesforce/apex/CommunityUserTaskController.updateTasks';
const actions = [
           
    {label: 'Edit', name: 'edit'},
   
];
const options = [
    { label: 'Not Started', value: 'Not Started' },
    { label: 'In Progress', value: 'In Progress' },
    { label: 'Completed', value: 'Completed' },
    { label: 'Deferred', value: 'Deferred' },
    { label: 'Pending', value: 'Pending' },
    { label: 'On Hold', value: 'On Hold' }    
];

import getTasks from '@salesforce/apex/CommunityUserTaskController.getTasks';
export default class CommunityUser extends LightningElement {
    userId = Id;
    @api recordId;
    @track data = [];
    @track options = options;
    @track draftValues = [];
    @track bShowModal = false;
    @track record;
    _dataValueUpdated =[];
    @track loaded=false;

    @wire(getTasks, {comuserid: '005J0000007NoC9IAK'})
    wiredRecord({error, data}){        
        if (error) {
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error loading User',
                    message: error.message,
                    variant: 'error',
                }),
            );
        } else if (data) {
            // eslint-disable-next-line no-console
            console.log('data: '+JSON.stringify(data));
           
        }

    }

    connectedCallback() {
        // eslint-disable-next-line no-console
        console.log('userId: '+this.userId);
        const uid= this.userId;

        getTasks({comuserid: uid})
            .then(result => {
                this.data = result;
                console.log('result: '+JSON.stringify(result));
            })
            .catch(error => {
                console.log('error: '+error);
            });
    }

    handleClick(){

    }

    // Row Action event to show the details of the record
    handleRowAction(event) {
        const row = event.detail.row;
        this.record = row;
        this.bShowModal = true; // display modal window
    }
 
    // to close modal window set 'bShowModal' tarck value as false
    closeModal() {
        this.bShowModal = false;
    }

    handlePermChange(event){     
        event.preventDefault();   
        this._dataValueUpdated =[];    
            let statusValue = event.detail.value;
            let taskId = event.target.dataset.mid;
          console.log('Data: '+statusValue +' '+taskId); 
          this.addRecords(taskId,statusValue)
            
    }

    addRecords(recid,status){
            const index = this._dataValueUpdated.findIndex((e) => e.Id === recid);
            window.console.log('index: '+index);
    
            if (index === -1) {
                window.console.log('STEP3'); 
                let tempVal ={ };  
                tempVal.Id = recid;                    
                tempVal.Status = status;                    
                this._dataValueUpdated.push(tempVal);
            }else{
                window.console.log('STEP4');
                this._dataValueUpdated[index].Status = status;               
                window.console.log(this._dataValueUpdated[index]);
            }                
                window.console.log(JSON.stringify(this._dataValueUpdated));
    }

    updateRecordsButton(){
        this.loaded=true;
        updateTasks({ tasklist: this._dataValueUpdated})
            .then(data => {
               window.console.log(data);    
               this.showNotification('Success','Task Updated Successfully','success');  
               this.loaded=false;         
            })
            .catch(error => {               
                this.error = error; 
                this.showNotification('Error', this.error,'error'); 
                this.loaded=false;                   
            });
    }

    showNotification(title,message,variant) {
        const evt = new ShowToastEvent({
            title: title,
            message: message,
            variant: variant,
        });
        this.dispatchEvent(evt);
    }
}